package See;
public class External{
	public int seemarks[];
	public External(){
		seemarks = new int[5];
	}
}
